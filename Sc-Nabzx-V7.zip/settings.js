const fs = require('fs');
const chalk = require('chalk');

/*
 
# Note:Jangan Hapus Credits Developer Script Ini ngehapus Credit? Gw Doain Sc Nya Eror

Developer: NabzxHost
Nomor Wa:6282178006414
Telegram:T.me/nabzxstore

*/

//~~~~~~~~~< GLOBAL SETTINGS >~~~~~~~~~\\

global.owner = ['625783089587']
global.ownerUtama = "6285783089587"
global.namaOwner = "NabXz"
global.packname = 'Bot WhatsApp'
global.botname = 'NabzxBotz'
global.tempatDB = 'database.json'
global.pairing_code = true
//==============================================
global.linkOwner = "https://wa.me/6285783089587"
global.linkGrup = "https://chat.whatsapp.com/EiaZeImefgDIsyDBN2c1XV"
global.linkGrup2 = "https://chat.whatsapp.com/EiaZeImefgDIsyDBN2c1XV"
global.linkSaluran = "https://whatsapp.com/channel/0029Vaiz6CQ7oQha5Al83B3e"
global.idsaluran = "120363330731459003@newsletter"
global.nameChannel = "Nabzxhostganteng"
global.linkytb = 'youtube.com/@NABZXHOSTING'
global.sosmed = 't.me/nabzxstore'
//==============================================

global.domainUtama = ""
global.cloudflareZone = ""
global.cloudflareApiKey = ""

//==============================================

global.api_id = "34499"
global.api_key = "10fxof-l0zg52-kaomt6-s9k6ts-bom8jy"
//==============================================
// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayjpmch = 100
global.delayPushkontak = 6000
//==============================================
// Settings buy panel otomatis 
global.apibotnabzx = "NabzxBotz"
global.linkgcreseller = "https://chat.whatsapp.com/HVHCGqiPUUmDIokQ9Vv6K2"
global.merchantIdOrderKuota = "OK2089124"
global.apiOrderKuota = "872050517318404372089124OKCT3D4F14C17B034E6ECEB27126A89882E8"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214621204751813560303UMI51440014ID.CO.QRIS.WWW0215ID20243511202980303UMI5204541153033605802ID5921NYOMANJEBEH OK20891246009SIJUNJUNG61052751162070703A0163048E2B"
global.pinOrkut = "0821"
global.pwOrkut = "BABIGOSONG"
//==============================================
//
global.apido = "dop_v1_71593d8b0bb2379c3e022e251d4e2dbb0599bdf0b31871b57b45086dc0e2fcc2" // Api digital ocean
//==============================================
// Settings Api Panel Pterodactyl v1
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://nabelsudahmandi.premium-cloud.my.id"
global.apikey = "ptla_TdRIgKTdQWoldlH6hN3vOF6FCljSDZOb36U285DxQt1" //ptla
global.capikey = "ptlc_gUEododNlpJ55LnIoK49KP4kowYKIoPfl9mlV34jrIP"
//==============================================
// Settings Api Panel Pterodactyl v2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://"
global.apikeyV2 = "" //ptla
global.capikeyV2 = "" //ptlc
//==============================================

global.domainbuy = "nabzxbotz.biz.id"
global.cfzone = "d971f3fd22d90a20f8da17879cf7b0ce"
global.cfapi = "hRd5vo1ExH0KhJ0iqdsRrn4BbT6u5rYcP5tgTPB2"

//==============================================
global.dana = "082178006414"
global.ovo = "082178006414"
global.gopay = "082178006414"
global.qris = "https://pomf2.lain.la/f/0zojum.jpg"
// Settings Api Subdomain
global.subdomain = {
"kenz-host.my.id": {
"zone": "df24766ae8eeb04b330b71b5facde5f4", 
"apitoken": "fyaxLxD0jNONtMWK3AmnaiLkkWi5Wg3Y9h8nqJh6"
},
"panelkishop.web.id": {
"zone": "8f4812b3c78ca478b5d162b6cb35d1b3", 
"apitoken": "3Y0cW3cVVIhyeWHytqFEbGDrdWaAC-k8twOEeFP2"
},
"tokopanelkishop.biz.id": {
"zone": "d87d4f320d9902f31fbbcc5ee23fafe8", 
"apitoken": "D00akOLxF3qzBzpYBp5SbpaLTmwYeybNsyAcDfiB"
},
"panelprivate.web.id": {
"zone": "61bcd80ff1ec9c3a5812f74d6ec24535", 
"apitoken": "VnjVDtbb-fSTFIn-3Hckd_E_eseqyHH7u1TTAHMN"
},
"rikionline.shop": {
"zone": "082ec80d7367d6d4f7c52600034ac635", 
"apitoken": "r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283", 
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE"
}, 
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887", 
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP"
}, 
"nabzxganteng.my.id": {
"zone": "d3aac5354f988960c7280401ec3ef601", 
"apitoken": "wO9i3UGSNCW7Q4PpAXfXwGUIFVxGONuIdDOGSl0b"
}, 
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35", 
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa", 
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs"
},
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
},
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}
}

global.mess = {
	owner: " *❌ ɴᴏᴛ ᴀᴄᴄᴇs*\n ᴏᴡɴᴇʀ ɴᴀʙ ᴏɴʟʏ",
	admin: " *❌ ɴᴏᴛ ᴀᴄᴄᴇs*\n ᴀᴅᴍɪɴ ɴᴀʙ ᴏɴʟʏ", 
	botAdmin: " *❌ ɴᴏᴛ ᴀᴄᴄᴇs*\n ʙᴏᴛ ɴᴏᴛ ᴀᴅᴍɪɴ",
	group: " *❌ sʏɴᴛᴀx ᴇʀʀᴏʀ*\n ɢʀᴏᴜᴘ ᴏɴʟʏ",
	private: " *❌ sʏɴᴛᴀx ᴇʀʀᴏʀ*\n ᴘʀɪᴠᴀᴛᴇ ᴏɴʟʏ",
	prem: " *❌ ɴᴏᴛ ᴀᴄᴄᴇs*\n ᴘʀᴇᴍɪᴜᴍ ɴᴀʙ ᴏɴʟʏ",
}
//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});